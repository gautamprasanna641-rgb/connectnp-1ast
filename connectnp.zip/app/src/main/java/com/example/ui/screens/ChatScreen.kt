package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.ConnectNpRepository
import com.example.data.SampleDataProvider
import com.example.model.*
import com.example.ui.theme.ConnectNpBlue
import com.example.ui.theme.ConnectNpSuccess
import com.example.ui.theme.NepalCrimson

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    threads: List<ChatThread>,
    messagesByThread: Map<String, List<ChatMessage>>,
    isNepali: Boolean,
    initialThreadId: String? = null,
    onSendMessage: (threadId: String, text: String, mediaType: MessageMediaType, audioDuration: Int?) -> Unit,
    onStartCall: (User, Boolean) -> Unit
) {
    var activeThreadId by remember(initialThreadId) { mutableStateOf(initialThreadId) }


    if (activeThreadId != null) {
        val currentThread = threads.find { it.id == activeThreadId }
        if (currentThread != null) {
            BackHandler { activeThreadId = null }
            ActiveChatView(
                thread = currentThread,
                messages = messagesByThread[currentThread.id] ?: emptyList(),
                isNepali = isNepali,
                onBack = { activeThreadId = null },
                onSendMessage = { text, mediaType, duration ->
                    onSendMessage(currentThread.id, text, mediaType, duration)
                },
                onStartCall = { isVideo ->
                    onStartCall(currentThread.user, isVideo)
                }
            )
            return
        }
    }

    // Chat List View
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .testTag("chat_screen")
    ) {
        // Active Friends Online Row
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(0.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(vertical = 8.dp)) {
                Text(
                    text = if (isNepali) "सक्रिय साथीहरू (Online)" else "Active Now",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )

                LazyRow(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(threads) { thread ->
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.clickable { activeThreadId = thread.id }
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (thread.isAiAssistant)
                                            Brush.linearGradient(listOf(ConnectNpBlue, NepalCrimson))
                                        else
                                            Brush.linearGradient(listOf(ConnectNpBlue, ConnectNpBlue))
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (thread.isAiAssistant) {
                                    Icon(
                                        imageVector = Icons.Default.SmartToy,
                                        contentDescription = "AI",
                                        tint = Color.White,
                                        modifier = Modifier.size(24.dp)
                                    )
                                } else {
                                    Text(
                                        text = thread.user.name.take(1),
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                if (thread.isOnline) {
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.BottomEnd)
                                            .size(12.dp)
                                            .clip(CircleShape)
                                            .border(2.dp, MaterialTheme.colorScheme.surface, CircleShape)
                                            .background(ConnectNpSuccess)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = if (thread.isAiAssistant) "AI Bot" else thread.user.name.split(" ").first(),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }

        // Conversation Threads List
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 80.dp)
        ) {
            items(threads, key = { it.id }) { thread ->
                ChatThreadItem(
                    thread = thread,
                    onClick = { activeThreadId = thread.id }
                )
                Divider(
                    color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f),
                    modifier = Modifier.padding(start = 74.dp)
                )
            }
        }
    }
}

@Composable
fun ChatThreadItem(
    thread: ChatThread,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .testTag("chat_thread_${thread.id}"),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Avatar
        Box(
            modifier = Modifier
                .size(50.dp)
                .clip(CircleShape)
                .background(
                    if (thread.isAiAssistant)
                        Brush.linearGradient(listOf(ConnectNpBlue, NepalCrimson))
                    else
                        Brush.linearGradient(listOf(ConnectNpBlue, ConnectNpBlue))
                ),
            contentAlignment = Alignment.Center
        ) {
            if (thread.isAiAssistant) {
                Icon(
                    imageVector = Icons.Default.SmartToy,
                    contentDescription = "AI",
                    tint = Color.White,
                    modifier = Modifier.size(26.dp)
                )
            } else {
                Text(
                    text = thread.user.name.take(1),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
            }

            if (thread.isOnline) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .size(13.dp)
                        .clip(CircleShape)
                        .border(2.dp, MaterialTheme.colorScheme.surface, CircleShape)
                        .background(ConnectNpSuccess)
                )
            }
        }

        Spacer(modifier = Modifier.width(12.dp))

        // Name & Last message
        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f, fill = false)
                ) {
                    Text(
                        text = thread.user.name,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    if (thread.user.isVerified || ConnectNpRepository.isUserVerified(thread.user.id)) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.Filled.Verified,
                            contentDescription = "Verified Blue Tick",
                            tint = ConnectNpBlue,
                            modifier = Modifier
                                .size(15.dp)
                                .testTag("chat_thread_verified_badge")
                        )
                    }
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = thread.lastMessageTime,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(2.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = thread.lastMessage,
                    fontSize = 13.sp,
                    color = if (thread.unreadCount > 0) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant,
                    fontWeight = if (thread.unreadCount > 0) FontWeight.SemiBold else FontWeight.Normal,
                    maxLines = 1,
                    modifier = Modifier.weight(1f)
                )

                if (thread.unreadCount > 0) {
                    Box(
                        modifier = Modifier
                            .size(20.dp)
                            .clip(CircleShape)
                            .background(NepalCrimson),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = thread.unreadCount.toString(),
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ActiveChatView(
    thread: ChatThread,
    messages: List<ChatMessage>,
    isNepali: Boolean,
    onBack: () -> Unit,
    onSendMessage: (text: String, mediaType: MessageMediaType, audioDuration: Int?) -> Unit,
    onStartCall: (isVideo: Boolean) -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val tts = remember(context) { com.example.util.ConnectNpTextToSpeech(context) }
    val currentlySpeakingId by tts.currentlySpeakingMessageId.collectAsState()

    DisposableEffect(tts) {
        onDispose {
            tts.shutdown()
        }
    }

    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val isAiThinking by ConnectNpRepository.isAiThinking.collectAsStateWithLifecycle()

    // Automatically scroll to latest message or thinking indicator
    LaunchedEffect(messages.size, isAiThinking) {
        val totalCount = messages.size + if (isAiThinking && thread.isAiAssistant) 1 else 0
        if (totalCount > 0) {
            listState.animateScrollToItem(totalCount - 1)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Chat Top Bar
        Surface(
            tonalElevation = 4.dp,
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                }

                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(
                            if (thread.isAiAssistant)
                                Brush.linearGradient(listOf(ConnectNpBlue, NepalCrimson))
                            else
                                Brush.linearGradient(listOf(ConnectNpBlue, ConnectNpBlue))
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (thread.isAiAssistant) {
                        Icon(
                            imageVector = Icons.Default.SmartToy,
                            contentDescription = "AI",
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    } else {
                        Text(
                            text = thread.user.name.take(1),
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = thread.user.name,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        if (thread.user.isVerified || ConnectNpRepository.isUserVerified(thread.user.id)) {
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Filled.Verified,
                                contentDescription = "Verified Blue Tick",
                                tint = ConnectNpBlue,
                                modifier = Modifier
                                    .size(14.dp)
                                    .testTag("active_chat_verified_badge")
                            )
                        }
                    }
                    Text(
                        text = if (thread.isAiAssistant) (if (isNepali) "AI सहायक • नेपाली आवाज 🔊" else "AI Companion • English TTS 🔊")
                               else if (thread.isOnline) "Online • End-to-End Encrypted" else "Last seen recently",
                        fontSize = 11.sp,
                        color = if (thread.isOnline || thread.isAiAssistant) ConnectNpSuccess else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Call buttons for peer chats only (not AI bot)
                if (!thread.isAiAssistant) {
                    // Audio Call
                    IconButton(onClick = { onStartCall(false) }) {
                        Icon(imageVector = Icons.Default.Call, contentDescription = "Call", tint = ConnectNpBlue)
                    }

                    // Video Call
                    IconButton(onClick = { onStartCall(true) }) {
                        Icon(imageVector = Icons.Default.Videocam, contentDescription = "Video", tint = ConnectNpBlue)
                    }
                }
            }
        }

        // Encryption notice badge
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        modifier = Modifier.size(12.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (thread.isAiAssistant) "🤖 AI conversation with multi-turn contextual memory" else "🔒 Messages are end-to-end encrypted on ConnectNP.",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // AI Assistant Quick Suggestion Chips
        if (thread.isAiAssistant) {
            LazyRow(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val suggestions = listOf(
                    "Best Momo in Kathmandu?",
                    "Annapurna trek guide",
                    "How to use ConnectNP Pay?",
                    "नमस्ते भन्नुहोस्"
                )
                items(suggestions) { prompt ->
                    SuggestionChip(
                        onClick = {
                            onSendMessage(prompt, MessageMediaType.TEXT, null)
                        },
                        label = { Text(prompt, fontSize = 11.sp) }
                    )
                }
            }
        }

        // Messages List with state for auto-scroll
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages, key = { it.id }) { msg ->
                val isAiMessage = !msg.isFromMe && (msg.senderId == "user_ai" || thread.isAiAssistant)
                ChatMessageBubble(
                    msg = msg,
                    isAiMessage = isAiMessage,
                    isSpeaking = currentlySpeakingId == msg.id,
                    onToggleSpeak = if (isAiMessage && msg.text.isNotBlank()) {
                        { tts.speak(msg.id, msg.text, isNepali) }
                    } else null
                )
            }

            // Real-time AI thinking indicator when Gemini is generating response
            if (isAiThinking && thread.isAiAssistant) {
                item {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .testTag("ai_thinking_indicator")
                    ) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(Brush.linearGradient(listOf(ConnectNpBlue, NepalCrimson))),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.SmartToy,
                                contentDescription = "AI Thinking",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            tonalElevation = 2.dp
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(14.dp),
                                    strokeWidth = 2.dp,
                                    color = ConnectNpBlue
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isNepali) "ConnectNP AI (Gemini) जवाफ तयार गर्दैछ..." else "ConnectNP AI (Gemini) is thinking...",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        // Bottom Input Bar
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = {}) {
                    Icon(imageVector = Icons.Outlined.EmojiEmotions, contentDescription = "Emoji")
                }

                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = { Text(if (isNepali) "सन्देश टाइप गर्नुहोस्..." else "Message...") },
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("chat_input_field"),
                    maxLines = 4
                )

                Spacer(modifier = Modifier.width(4.dp))

                // Voice Note or Send
                if (inputText.isBlank()) {
                    IconButton(
                        onClick = {
                            onSendMessage("Voice message", MessageMediaType.AUDIO_VOICE, 8)
                        },
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(NepalCrimson)
                    ) {
                        Icon(imageVector = Icons.Default.Mic, contentDescription = "Voice Note", tint = Color.White)
                    }
                } else {
                    IconButton(
                        onClick = {
                            if (inputText.isNotBlank()) {
                                onSendMessage(inputText, MessageMediaType.TEXT, null)
                                inputText = ""
                            }
                        },
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(ConnectNpBlue)
                            .testTag("chat_send_button")
                    ) {
                        Icon(imageVector = Icons.Default.Send, contentDescription = "Send", tint = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
fun ChatMessageBubble(
    msg: ChatMessage,
    isAiMessage: Boolean = false,
    isSpeaking: Boolean = false,
    onToggleSpeak: (() -> Unit)? = null
) {
    val isMe = msg.isFromMe
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isMe) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isMe) 16.dp else 4.dp,
                bottomEnd = if (isMe) 4.dp else 16.dp
            ),
            color = if (isMe) ConnectNpBlue else MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.widthIn(max = 280.dp)
        ) {
            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                if (msg.mediaType == MessageMediaType.AUDIO_VOICE) {
                    // Voice Note simulation
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayCircle,
                            contentDescription = "Play",
                            tint = if (isMe) Color.White else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(28.dp)
                        )
                        Column {
                            Text(
                                text = " ılılıllı|l|ılıl| ",
                                fontWeight = FontWeight.Bold,
                                color = if (isMe) Color.White else MaterialTheme.colorScheme.onSurface,
                                fontSize = 16.sp
                            )
                            Text(
                                text = "0:0${msg.audioDurationSec ?: 8} • Voice Message",
                                fontSize = 10.sp,
                                color = if (isMe) Color.White.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                } else {
                    Text(
                        text = msg.text,
                        color = if (isMe) Color.White else MaterialTheme.colorScheme.onSurface,
                        fontSize = 14.sp
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (isAiMessage && onToggleSpeak != null) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isSpeaking) NepalCrimson.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface.copy(alpha = 0.5f),
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { onToggleSpeak() }
                                .testTag("speaker_tts_button_${msg.id}")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Icon(
                                    imageVector = if (isSpeaking) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                                    contentDescription = if (isSpeaking) "Stop voice" else "Listen to voice",
                                    tint = if (isSpeaking) NepalCrimson else ConnectNpBlue,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                                Text(
                                    text = if (isSpeaking) "Stop" else "Listen",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (isSpeaking) NepalCrimson else ConnectNpBlue
                                )
                            }
                        }
                    } else {
                        Spacer(modifier = Modifier.width(1.dp))
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = msg.timestamp,
                            fontSize = 10.sp,
                            color = if (isMe) Color.White.copy(alpha = 0.7f) else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        if (isMe) {
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.DoneAll,
                                contentDescription = "Read",
                                tint = Color.White.copy(alpha = 0.9f),
                                modifier = Modifier.size(12.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

