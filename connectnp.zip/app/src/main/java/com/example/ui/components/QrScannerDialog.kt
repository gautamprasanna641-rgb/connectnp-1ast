package com.example.ui.components

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.data.ConnectNpRepository
import com.example.ui.theme.ConnectNpBlue
import com.example.ui.theme.NepalCrimson
import com.google.zxing.*
import com.google.zxing.common.HybridBinarizer
import org.json.JSONObject
import java.util.concurrent.Executors

/**
 * Parsed QR Payment content
 */
data class QrPaymentDetails(
    val recipient: String,
    val amount: Double? = null,
    val remarks: String? = null,
    val rawText: String = ""
)

/**
 * Parses payment metadata from scanned QR content
 * Supports:
 * - CONNECTNP deep link URI (connectnp:pay?recipient=Name&amount=500&remarks=Food)
 * - UPI style (upi://pay?pn=Name&am=500)
 * - Profile URL (connectnp.me/@handle or connectnp.me/name)
 * - JSON payload ({"recipient":"Name", "amount": 500})
 * - Raw username/handle/phone number
 */
fun parseQrPaymentDetails(qrContent: String): QrPaymentDetails {
    val trimmed = qrContent.trim()
    if (trimmed.isBlank()) {
        return QrPaymentDetails(recipient = "ConnectNP Member", rawText = qrContent)
    }

    // Format 1: connectnp:pay?... or upi://pay?...
    if (trimmed.startsWith("connectnp:", ignoreCase = true) || trimmed.startsWith("upi:", ignoreCase = true)) {
        try {
            val uri = Uri.parse(trimmed)
            val recipient = uri.getQueryParameter("recipient")
                ?: uri.getQueryParameter("pn")
                ?: uri.getQueryParameter("pa")
                ?: uri.getQueryParameter("name")
                ?: uri.getQueryParameter("user")
                ?: ""
            val amountStr = uri.getQueryParameter("amount") ?: uri.getQueryParameter("am")
            val amount = amountStr?.toDoubleOrNull()
            val remarks = uri.getQueryParameter("remarks") ?: uri.getQueryParameter("note")
            if (recipient.isNotBlank()) {
                return QrPaymentDetails(
                    recipient = recipient,
                    amount = amount,
                    remarks = remarks,
                    rawText = qrContent
                )
            }
        } catch (e: Exception) {
            // continue fallback
        }
    }

    // Format 2: connectnp.me/@username or connectnp.me/username
    if (trimmed.contains("connectnp.me/", ignoreCase = true)) {
        val segment = trimmed.substringAfter("connectnp.me/").substringBefore("?").substringBefore("/")
        if (segment.isNotBlank()) {
            val clean = if (segment.startsWith("@")) segment else "@$segment"
            return QrPaymentDetails(recipient = clean, rawText = qrContent)
        }
    }

    // Format 3: JSON payload
    if (trimmed.startsWith("{") && trimmed.endsWith("}")) {
        try {
            val json = JSONObject(trimmed)
            val recipient = json.optString("recipient", json.optString("name", json.optString("handle", "")))
            val amount = if (json.has("amount")) json.optDouble("amount") else null
            val remarks = json.optString("remarks", null)
            if (recipient.isNotBlank()) {
                return QrPaymentDetails(recipient = recipient, amount = amount, remarks = remarks, rawText = qrContent)
            }
        } catch (e: Exception) {
            // fallback
        }
    }

    // Format 4: Raw receiver name, phone or handle
    return QrPaymentDetails(recipient = trimmed, rawText = qrContent)
}

/**
 * Decodes QR code from a static Bitmap using ZXing
 */
fun decodeQrFromBitmap(bitmap: Bitmap): String? {
    val width = bitmap.width
    val height = bitmap.height
    val pixels = IntArray(width * height)
    bitmap.getPixels(pixels, 0, width, 0, 0, width, height)
    val source = RGBLuminanceSource(width, height, pixels)
    val binaryBitmap = BinaryBitmap(HybridBinarizer(source))
    val reader = MultiFormatReader().apply {
        setHints(mapOf(
            DecodeHintType.POSSIBLE_FORMATS to listOf(BarcodeFormat.QR_CODE),
            DecodeHintType.TRY_HARDER to true
        ))
    }
    return try {
        reader.decodeWithState(binaryBitmap).text
    } catch (e: Exception) {
        null
    }
}

/**
 * CameraX ImageAnalysis Analyzer powered by ZXing
 */
class QrCodeAnalyzer(
    private val onQrCodeDetected: (String) -> Unit
) : ImageAnalysis.Analyzer {

    private val reader = MultiFormatReader().apply {
        val hints = mapOf(
            DecodeHintType.POSSIBLE_FORMATS to listOf(BarcodeFormat.QR_CODE),
            DecodeHintType.TRY_HARDER to true,
            DecodeHintType.CHARACTER_SET to "UTF-8"
        )
        setHints(hints)
    }

    @Volatile
    private var isScanning = true

    override fun analyze(imageProxy: ImageProxy) {
        if (!isScanning) {
            imageProxy.close()
            return
        }

        try {
            val plane = imageProxy.planes.firstOrNull()
            if (plane != null) {
                val buffer = plane.buffer
                val data = ByteArray(buffer.remaining())
                buffer.get(data)

                val width = imageProxy.width
                val height = imageProxy.height
                val rotation = imageProxy.imageInfo.rotationDegrees

                val source = if (rotation == 90 || rotation == 270) {
                    // Rotate luminance bytes to match portrait preview
                    val rotatedData = ByteArray(data.size)
                    for (y in 0 until height) {
                        for (x in 0 until width) {
                            val targetIndex = if (rotation == 90) {
                                x * height + (height - y - 1)
                            } else {
                                (width - x - 1) * height + y
                            }
                            if (targetIndex in rotatedData.indices && (x + y * width) in data.indices) {
                                rotatedData[targetIndex] = data[x + y * width]
                            }
                        }
                    }
                    PlanarYUVLuminanceSource(rotatedData, height, width, 0, 0, height, width, false)
                } else {
                    PlanarYUVLuminanceSource(data, width, height, 0, 0, width, height, false)
                }

                val binaryBitmap = BinaryBitmap(HybridBinarizer(source))
                val result = reader.decodeWithState(binaryBitmap)
                if (!result.text.isNullOrBlank()) {
                    isScanning = false
                    onQrCodeDetected(result.text)
                }
            }
        } catch (e: Exception) {
            // Not a QR frame, continue scanning
        } finally {
            reader.reset()
            imageProxy.close()
        }
    }
}

@Composable
fun QrScannerDialog(
    onDismiss: () -> Unit,
    onScanSuccess: (String) -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var selectedTab by remember { mutableIntStateOf(1) } // Default to 1 = Scanner
    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }
    val hasCameraHardware = remember {
        context.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY)
    }
    var cameraError by remember { mutableStateOf<String?>(null) }
    var isDecodingGalleryImage by remember { mutableStateOf(false) }
    var manualReceiverInput by remember { mutableStateOf("") }
    var showManualInput by remember { mutableStateOf(false) }

    // Camera permission request launcher
    val cameraPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        hasCameraPermission = isGranted
        if (!isGranted) {
            Toast.makeText(context, "Camera permission is required to scan QR codes", Toast.LENGTH_SHORT).show()
        }
    }

    // Photo picker launcher for scanning QR from saved photos/gallery
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            isDecodingGalleryImage = true
            try {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    val bitmap = BitmapFactory.decodeStream(stream)
                    if (bitmap != null) {
                        val qrResult = decodeQrFromBitmap(bitmap)
                        if (!qrResult.isNullOrBlank()) {
                            Toast.makeText(context, "QR code detected successfully!", Toast.LENGTH_SHORT).show()
                            onScanSuccess(qrResult)
                            onDismiss()
                        } else {
                            Toast.makeText(context, "No valid QR code found in selected image", Toast.LENGTH_LONG).show()
                        }
                    } else {
                        Toast.makeText(context, "Unable to read image", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Error reading image: ${e.message}", Toast.LENGTH_SHORT).show()
            } finally {
                isDecodingGalleryImage = false
            }
        }
    }

    // Auto-request permission when scanner tab is opened
    LaunchedEffect(selectedTab) {
        if (selectedTab == 1 && !hasCameraPermission && hasCameraHardware) {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
                .testTag("qr_scanner_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(NepalCrimson.copy(alpha = 0.12f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.QrCodeScanner,
                                contentDescription = null,
                                tint = NepalCrimson,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "CONNECTNP QR",
                            fontFamily = com.example.ui.theme.PoppinsFontFamily,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.onSurface,
                            letterSpacing = 0.5.sp
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", modifier = Modifier.size(20.dp))
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Tabs: Scanner vs My QR Code
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                ) {
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        text = { Text("Scan QR", fontWeight = FontWeight.Bold, fontSize = 13.sp) },
                        icon = { Icon(Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        modifier = Modifier.testTag("tab_qr_scanner")
                    )
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        text = { Text("My QR Code", fontWeight = FontWeight.Bold, fontSize = 13.sp) },
                        icon = { Icon(Icons.Default.QrCode, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        modifier = Modifier.testTag("tab_my_qr")
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                if (selectedTab == 1) {
                    // --- SCANNER VIEW ---
                    if (!hasCameraHardware) {
                        // Error State 1: No camera hardware available
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(230.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(16.dp)
                            ) {
                                Icon(Icons.Default.VideocamOff, contentDescription = null, tint = NepalCrimson, modifier = Modifier.size(44.dp))
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("Camera Not Available", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "No physical camera was found on this device or emulator. You can scan from a saved QR screenshot or enter details below.",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    } else if (!hasCameraPermission) {
                        // Error State 2: Permission not granted
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(230.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(16.dp)
                            ) {
                                Icon(Icons.Default.CameraAlt, contentDescription = null, tint = ConnectNpBlue, modifier = Modifier.size(44.dp))
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("Camera Access Needed", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Please allow camera access to scan CONNECTNP payment and profile QR codes.",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Button(
                                    onClick = { cameraPermissionLauncher.launch(Manifest.permission.CAMERA) },
                                    colors = ButtonDefaults.buttonColors(containerColor = ConnectNpBlue),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.testTag("grant_camera_permission_button")
                                ) {
                                    Text("Grant Permission", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }
                    } else if (cameraError != null) {
                        // Error State 3: Camera initialization error
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(230.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier.padding(16.dp)
                            ) {
                                Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = NepalCrimson, modifier = Modifier.size(40.dp))
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("Camera Error", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text(
                                    text = cameraError ?: "Failed to start camera",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                OutlinedButton(
                                    onClick = { cameraError = null },
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Retry", fontSize = 12.sp)
                                }
                            }
                        }
                    } else {
                        // Active Live Camera Scanner View
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(240.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color.Black)
                                .testTag("camera_preview_box"),
                            contentAlignment = Alignment.Center
                        ) {
                            AndroidView(
                                factory = { ctx ->
                                    val previewView = PreviewView(ctx).apply {
                                        scaleType = PreviewView.ScaleType.FILL_CENTER
                                    }
                                    val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                                    val cameraExecutor = Executors.newSingleThreadExecutor()

                                    cameraProviderFuture.addListener({
                                        try {
                                            val cameraProvider = cameraProviderFuture.get()
                                            val preview = Preview.Builder().build().also {
                                                it.setSurfaceProvider(previewView.surfaceProvider)
                                            }
                                            val imageAnalysis = ImageAnalysis.Builder()
                                                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                                                .build()
                                                .also {
                                                    it.setAnalyzer(cameraExecutor, QrCodeAnalyzer { qrText ->
                                                        (ctx as? android.app.Activity)?.runOnUiThread {
                                                            onScanSuccess(qrText)
                                                            onDismiss()
                                                        }
                                                    })
                                                }

                                            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
                                            cameraProvider.unbindAll()
                                            cameraProvider.bindToLifecycle(
                                                lifecycleOwner,
                                                cameraSelector,
                                                preview,
                                                imageAnalysis
                                            )
                                        } catch (e: Exception) {
                                            cameraError = e.localizedMessage ?: "Camera preview failed"
                                        }
                                    }, ContextCompat.getMainExecutor(ctx))

                                    previewView
                                },
                                modifier = Modifier.fillMaxSize()
                            )

                            // Glowing Viewfinder Reticle Overlay
                            Box(
                                modifier = Modifier
                                    .size(160.dp)
                                    .border(2.5.dp, ConnectNpBlue, RoundedCornerShape(12.dp))
                            )

                            // Helper text overlay
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = Color.Black.copy(alpha = 0.6f),
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .padding(bottom = 10.dp)
                            ) {
                                Text(
                                    text = "Align CONNECTNP QR code inside frame",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Secondary Actions: Scan from Gallery & Manual receiver entry
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp)
                                .testTag("scan_gallery_button"),
                            contentPadding = PaddingValues(horizontal = 8.dp)
                        ) {
                            if (isDecodingGalleryImage) {
                                CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp)
                            } else {
                                Icon(Icons.Outlined.PhotoLibrary, contentDescription = null, modifier = Modifier.size(16.dp), tint = ConnectNpBlue)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("From Gallery", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Button(
                            onClick = { showManualInput = !showManualInput },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (showManualInput) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.surfaceVariant,
                                contentColor = if (showManualInput) Color.White else MaterialTheme.colorScheme.onSurface
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .height(40.dp)
                                .testTag("toggle_manual_qr_input"),
                            contentPadding = PaddingValues(horizontal = 8.dp)
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(15.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (showManualInput) "Hide Input" else "Enter Code", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    // Expandable Manual/Test Input
                    AnimatedVisibility(visible = showManualInput) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 10.dp)
                        ) {
                            OutlinedTextField(
                                value = manualReceiverInput,
                                onValueChange = { manualReceiverInput = it },
                                placeholder = { Text("Receiver name, @handle or QR text", fontSize = 12.sp) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("manual_qr_input_field"),
                                shape = RoundedCornerShape(10.dp),
                                singleLine = true
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Button(
                                    onClick = {
                                        if (manualReceiverInput.isNotBlank()) {
                                            onScanSuccess(manualReceiverInput.trim())
                                            onDismiss()
                                        } else {
                                            Toast.makeText(context, "Please enter receiver details", Toast.LENGTH_SHORT).show()
                                        }
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = NepalCrimson),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("submit_manual_qr_button")
                                ) {
                                    Text("Pay Receiver", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }

                                OutlinedButton(
                                    onClick = {
                                        onScanSuccess("connectnp:pay?recipient=Dipak%20Giri&handle=@dipak_giri&amount=500&remarks=Lunch")
                                        onDismiss()
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Test QR (Dipak)", fontSize = 11.sp)
                                }
                            }
                        }
                    }

                } else {
                    // --- MY QR CODE VIEW ---
                    val activeUser = ConnectNpRepository.getCurrentActiveUser()
                    val myQrPayload = "connectnp:pay?recipient=${Uri.encode(activeUser.name)}&handle=${Uri.encode(activeUser.handle)}"

                    Box(
                        modifier = Modifier
                            .size(200.dp)
                            .clip(RoundedCornerShape(18.dp))
                            .border(
                                3.dp,
                                Brush.linearGradient(listOf(ConnectNpBlue, NepalCrimson)),
                                RoundedCornerShape(18.dp)
                            )
                            .background(Color.White)
                            .testTag("my_qr_code_card"),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.QrCode,
                                contentDescription = "My Payment QR Code",
                                tint = Color.Black,
                                modifier = Modifier.size(135.dp)
                            )
                            Text(
                                text = "connectnp.me/${activeUser.handle.removePrefix("@")}",
                                fontSize = 10.sp,
                                color = Color.Gray,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = activeUser.name,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "${activeUser.handle} • Nepal Verified P2P",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = {
                            val sendIntent = Intent().apply {
                                action = Intent.ACTION_SEND
                                putExtra(Intent.EXTRA_TEXT, "Pay me on CONNECTNP via QR or username: $myQrPayload")
                                type = "text/plain"
                            }
                            context.startActivity(Intent.createChooser(sendIntent, "Share Payment QR"))
                        },
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ConnectNpBlue),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("share_qr_button")
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "SHARE PAYMENT QR",
                            fontFamily = com.example.ui.theme.PoppinsFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            letterSpacing = 0.5.sp
                        )
                    }
                }
            }
        }
    }
}
